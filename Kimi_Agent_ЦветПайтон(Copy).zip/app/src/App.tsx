import { useState, useCallback, useRef } from "react";
import CodeMirror from "@uiw/react-codemirror";
import { python } from "@codemirror/lang-python";
import { oneDark } from "@codemirror/theme-one-dark";

const STARTER_CODE = `#!/usr/bin/env python3
"""
Python Code Studio — пример программы.
Пишите здесь любой код: маленькие скрипты или огромные проекты.
Редактор поддерживает файлы на тысячи строк без тормозов.
"""

import math
import random


class Particle:
    """Частица с позицией и скоростью."""

    def __init__(self, x: float, y: float):
        self.x = x
        self.y = y
        self.vx = random.uniform(-1, 1)
        self.vy = random.uniform(-1, 1)

    def step(self, dt: float = 0.016) -> None:
        self.x += self.vx * dt
        self.y += self.vy * dt

    @property
    def speed(self) -> float:
        return math.hypot(self.vx, self.vy)


def simulate(count: int = 100, steps: int = 60) -> list[Particle]:
    particles = [Particle(0.0, 0.0) for _ in range(count)]
    for _ in range(steps):
        for p in particles:
            p.step()
    return particles


if __name__ == "__main__":
    ps = simulate(count=10, steps=120)
    fastest = max(ps, key=lambda p: p.speed)
    print(f"Самая быстрая частица: скорость {fastest.speed:.3f}")
`;

interface Tab {
  id: number;
  name: string;
  code: string;
}

let nextId = 2;

export default function App() {
  const [tabs, setTabs] = useState<Tab[]>([{ id: 1, name: "main.py", code: STARTER_CODE }]);
  const [activeId, setActiveId] = useState(1);
  const [fontSize, setFontSize] = useState(15);
  const [copied, setCopied] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const active = tabs.find((t) => t.id === activeId) ?? tabs[0];
  const lineCount = active.code.split("\n").length;
  const charCount = active.code.length;

  const updateCode = useCallback(
    (value: string) => {
      setTabs((ts) => ts.map((t) => (t.id === activeId ? { ...t, code: value } : t)));
    },
    [activeId]
  );

  const addTab = () => {
    const t: Tab = { id: nextId, name: `script${nextId}.py`, code: "# Новый файл\n" };
    nextId += 1;
    setTabs((ts) => [...ts, t]);
    setActiveId(t.id);
  };

  const closeTab = (id: number) => {
    setTabs((ts) => {
      const rest = ts.filter((t) => t.id !== id);
      if (rest.length === 0) return ts;
      if (id === activeId) setActiveId(rest[rest.length - 1].id);
      return rest;
    });
  };

  const download = () => {
    const blob = new Blob([active.code], { type: "text/x-python" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = active.name;
    a.click();
    URL.revokeObjectURL(url);
  };

  const copyAll = async () => {
    try {
      await navigator.clipboard.writeText(active.code);
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    } catch {
      /* clipboard unavailable */
    }
  };

  const openFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    file.text().then((text) => {
      const t: Tab = { id: nextId, name: file.name, code: text };
      nextId += 1;
      setTabs((ts) => [...ts, t]);
      setActiveId(t.id);
    });
    e.target.value = "";
  };

  return (
    <div className="flex h-[100dvh] flex-col bg-[#0d1117] text-[#e6edf3]">
      {/* Header */}
      <header className="flex flex-wrap items-center gap-2 border-b border-[#21262d] bg-[#010409] px-3 py-2 sm:px-4">
        <div className="flex items-center gap-2">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" aria-hidden="true">
            <path d="M12 2c-2.6 0-4.5 1.1-4.5 3v2.3h4.6v.8H5.6c-1.9 0-3.6 1.8-3.6 4.4s1.6 4.3 3.6 4.3h2v-2.6c0-1.7 1.4-3.1 3.1-3.1h5.2c1.5 0 2.6-1.2 2.6-2.7V5c0-1.9-1.9-3-4.5-3H12zm-2.3 2.2a.85.85 0 1 1 0 1.7.85.85 0 0 1 0-1.7z" fill="#3776AB"/>
            <path d="M12 22c2.6 0 4.5-1.1 4.5-3v-2.3h-4.6v-.8h6.5c1.9 0 3.6-1.8 3.6-4.4s-1.6-4.3-3.6-4.3h-2v2.6c0 1.7-1.4 3.1-3.1 3.1H7.6c-1.5 0-2.6 1.2-2.6 2.7V19c0 1.9 1.9 3 4.5 3h2zm2.3-2.2a.85.85 0 1 1 0-1.7.85.85 0 0 1 0 1.7z" fill="#FFD43B"/>
          </svg>
          <h1 className="text-sm font-semibold tracking-wide sm:text-base">Python Code Studio</h1>
        </div>
        <div className="ml-auto flex flex-wrap items-center gap-2">
          <label className="flex items-center gap-1 text-xs text-[#8b949e]">
            Шрифт
            <input
              type="range"
              min={12}
              max={22}
              value={fontSize}
              onChange={(e) => setFontSize(Number(e.target.value))}
              className="h-8 w-20 accent-[#58a6ff] sm:w-24"
              aria-label="Размер шрифта"
            />
            <span className="w-6 text-right">{fontSize}</span>
          </label>
          <button
            onClick={() => fileInputRef.current?.click()}
            className="min-h-[44px] cursor-pointer rounded-md border border-[#30363d] bg-[#21262d] px-3 py-1.5 text-xs font-medium transition-colors hover:bg-[#30363d] focus-visible:outline-2 focus-visible:outline-[#58a6ff] sm:min-h-0 sm:py-1.5"
          >
            Открыть .py
          </button>
          <input ref={fileInputRef} type="file" accept=".py,.txt" className="hidden" onChange={openFile} />
          <button
            onClick={copyAll}
            className="min-h-[44px] cursor-pointer rounded-md border border-[#30363d] bg-[#21262d] px-3 py-1.5 text-xs font-medium transition-colors hover:bg-[#30363d] focus-visible:outline-2 focus-visible:outline-[#58a6ff] sm:min-h-0 sm:py-1.5"
          >
            {copied ? "Скопировано!" : "Копировать"}
          </button>
          <button
            onClick={download}
            className="min-h-[44px] cursor-pointer rounded-md bg-[#238636] px-3 py-1.5 text-xs font-semibold text-white transition-colors hover:bg-[#2ea043] focus-visible:outline-2 focus-visible:outline-[#58a6ff] sm:min-h-0 sm:py-1.5"
          >
            Скачать
          </button>
        </div>
      </header>

      {/* Tabs */}
      <div className="flex items-end gap-0.5 overflow-x-auto border-b border-[#21262d] bg-[#010409] px-2 pt-1.5" role="tablist">
        {tabs.map((t) => (
          <div
            key={t.id}
            role="tab"
            aria-selected={t.id === activeId}
            tabIndex={0}
            onClick={() => setActiveId(t.id)}
            onKeyDown={(e) => { if (e.key === "Enter" || e.key === " ") setActiveId(t.id); }}
            className={`group flex min-h-[44px] cursor-pointer items-center gap-1.5 rounded-t-md px-3 text-xs whitespace-nowrap transition-colors sm:min-h-0 sm:py-2 ${
              t.id === activeId
                ? "bg-[#0d1117] text-[#e6edf3]"
                : "text-[#8b949e] hover:bg-[#161b22] hover:text-[#c9d1d9]"
            }`}
          >
            <span className="font-mono">{t.name}</span>
            {tabs.length > 1 && (
              <button
                aria-label={`Закрыть ${t.name}`}
                onClick={(e) => { e.stopPropagation(); closeTab(t.id); }}
                className="cursor-pointer rounded px-1 text-[#8b949e] opacity-60 transition-opacity hover:bg-[#30363d] hover:text-[#e6edf3] hover:opacity-100 focus-visible:outline-2 focus-visible:outline-[#58a6ff]"
              >
                ×
              </button>
            )}
          </div>
        ))}
        <button
          onClick={addTab}
          aria-label="Новый файл"
          className="mb-1 min-h-[44px] min-w-[44px] cursor-pointer rounded-md px-2 text-lg text-[#8b949e] transition-colors hover:bg-[#21262d] hover:text-[#e6edf3] focus-visible:outline-2 focus-visible:outline-[#58a6ff] sm:min-h-0 sm:min-w-0 sm:py-1"
        >
          +
        </button>
      </div>

      {/* Editor */}
      <div className="min-h-0 flex-1 overflow-hidden">
        <CodeMirror
          value={active.code}
          onChange={updateCode}
          extensions={[python()]}
          theme={oneDark}
          height="100%"
          style={{ height: "100%", fontSize: `${fontSize}px` }}
          basicSetup={{
            lineNumbers: true,
            highlightActiveLine: true,
            highlightActiveLineGutter: true,
            foldGutter: true,
            autocompletion: true,
            bracketMatching: true,
            closeBrackets: true,
            indentOnInput: true,
            searchKeymap: true,
          }}
        />
      </div>

      {/* Status bar */}
      <footer className="flex items-center gap-4 border-t border-[#21262d] bg-[#010409] px-4 py-1.5 font-mono text-[11px] text-[#8b949e]">
        <span className="text-[#58a6ff]">Python 3</span>
        <span>{active.name}</span>
        <span className="ml-auto">Строк: {lineCount.toLocaleString("ru-RU")}</span>
        <span>Символов: {charCount.toLocaleString("ru-RU")}</span>
      </footer>
    </div>
  );
}
